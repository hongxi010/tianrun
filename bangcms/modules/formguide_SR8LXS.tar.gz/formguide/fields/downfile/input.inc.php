function downfile($field, $value) {
        return trim($value);
}