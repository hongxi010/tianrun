	function editor($field, $value) {
		return $value;
	}
