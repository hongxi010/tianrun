<?php 
defined('IN_BANGCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

$module = 'formguide';
$modulename = '表单向导模块';
$introduce = '独立模块';
$author = 'BangCMS Team';
$authorsite = 'http://www.zhengbang.com.cn';
$authoremail = '';
?>