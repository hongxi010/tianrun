<?php 
defined('IN_BANGCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

?>