<?php 
defined('IN_BANGCMS') or exit('Access Denied');
defined('UNINSTALL') or exit('Access Denied');

?>